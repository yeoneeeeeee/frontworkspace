package com.kh.run;

import com.kh.view.MemberView;

public class Run {

	public static void main(String[] args) {
		MemberView mv = new MemberView();
		mv.mainMenu();
	}
}
